/* Tamil Client Payment Reminder — Service Worker */
const CACHE = 'tcpr-cache-v1';
const PRECACHE = [
  '/',
  '/index.html',
  '/manifest.webmanifest',
  '/icons/icon-192.png',
  '/icons/icon-512.png',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches
      .open(CACHE)
      .then((cache) => cache.addAll(PRECACHE))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

/*
 * Caching strategy:
 *  - Navigations: network-first, fall back to cached index.html (SPA offline shell)
 *  - Everything else (JS/CSS/fonts/images, incl. Google Fonts): cache-first,
 *    then network + store, so the app works fully offline after the first visit.
 */
self.addEventListener('fetch', (event) => {
  const request = event.request;
  if (request.method !== 'GET') return;

  if (request.mode === 'navigate') {
    event.respondWith(
      fetch(request)
        .then((response) => {
          const copy = response.clone();
          caches.open(CACHE).then((cache) => cache.put('/index.html', copy));
          return response;
        })
        .catch(() => caches.match('/index.html'))
    );
    return;
  }

  event.respondWith(
    caches.match(request).then((cached) => {
      if (cached) return cached;
      return fetch(request)
        .then((response) => {
          if (response && (response.ok || response.type === 'opaque')) {
            const copy = response.clone();
            caches.open(CACHE).then((cache) => cache.put(request, copy));
          }
          return response;
        })
        .catch(() => cached);
    })
  );
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((list) => {
      for (const client of list) {
        if ('focus' in client) return client.focus();
      }
      return self.clients.openWindow('/');
    })
  );
});

/* ------- Periodic background check (Android / Chromium, where supported) ------- */

function clampedDueDate(dueDay, year, monthIndex) {
  const last = new Date(year, monthIndex + 1, 0).getDate();
  return new Date(year, monthIndex, Math.min(dueDay, last));
}

function periodKey(d) {
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0');
}

function readClients() {
  return new Promise((resolve) => {
    const open = indexedDB.open('tcpr-db');
    open.onerror = () => resolve([]);
    open.onsuccess = () => {
      const db = open.result;
      if (!db.objectStoreNames.contains('clients')) {
        resolve([]);
        return;
      }
      const req = db.transaction('clients', 'readonly').objectStore('clients').getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => resolve([]);
    };
  });
}

self.addEventListener('periodicsync', (event) => {
  if (event.tag !== 'tcpr-check') return;
  event.waitUntil(
    readClients().then((clients) => {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const pk = periodKey(today);
      let due5 = 0;
      let dueToday = 0;
      let overdue = 0;
      for (const c of clients) {
        if (c.lastPaidPeriod === pk) continue;
        const due = clampedDueDate(c.dueDay, today.getFullYear(), today.getMonth());
        const days = Math.round((due.getTime() - today.getTime()) / 86400000);
        if (days < 0) overdue += 1;
        else if (days === 0) dueToday += 1;
        else if (days === 5) due5 += 1;
      }
      if (due5 + dueToday + overdue === 0) return;
      const parts = [];
      if (overdue) parts.push(overdue + ' தாமதம் / overdue');
      if (dueToday) parts.push(dueToday + ' இன்று / due today');
      if (due5) parts.push(due5 + ' 5 நாட்களில் / in 5 days');
      return self.registration.showNotification('⏰ கட்டண நினைவூட்டல் | Payment reminder', {
        body: parts.join(' · '),
        icon: '/icons/icon-192.png',
        badge: '/icons/icon-192.png',
        tag: 'tcpr-periodic',
        renotify: true,
        vibrate: [300, 150, 300, 150, 300],
      });
    })
  );
});
