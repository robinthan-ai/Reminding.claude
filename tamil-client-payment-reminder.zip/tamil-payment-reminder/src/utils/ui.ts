import type { ComputedStatus } from '../types';
import type { TranslationKey } from '../i18n';

export const statusChip: Record<ComputedStatus, string> = {
  paid: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-500/15 dark:text-emerald-300',
  pending: 'bg-slate-100 text-slate-600 dark:bg-slate-700/60 dark:text-slate-300',
  dueSoon: 'bg-manjal-100 text-manjal-600 dark:bg-manjal-500/15 dark:text-manjal-400',
  overdue: 'bg-rose-100 text-rose-700 dark:bg-rose-500/15 dark:text-rose-300',
};

export const statusDot: Record<ComputedStatus, string> = {
  paid: 'bg-emerald-500',
  pending: 'bg-slate-400',
  dueSoon: 'bg-manjal-500',
  overdue: 'bg-rose-500',
};

export const statusLabelKey: Record<ComputedStatus, TranslationKey> = {
  paid: 'paid',
  pending: 'pending',
  dueSoon: 'dueSoon',
  overdue: 'overdue',
};

export function money(amount: number, currency: string): string {
  return `${amount.toLocaleString('fr-FR')} ${currency}`;
}

export function initials(name: string): string {
  return name.trim().charAt(0).toUpperCase() || '?';
}
