import type { ClientView, Lang, Settings, Tone } from '../types';
import { formatDate, formatMonth } from './dates';

/**
 * Replaces {{client_name}}, {{amount}}, {{due_date}} and {{month}} with the
 * client's live values. Dates and months follow the app language, and are
 * recomputed automatically every cycle — so the same template stays correct
 * forever without manual edits.
 */
export function renderTemplate(template: string, client: ClientView, settings: Settings): string {
  const lang = settings.language;
  return template
    .replaceAll('{{client_name}}', client.name)
    .replaceAll('{{amount}}', `${client.amount} ${settings.currency}`)
    .replaceAll('{{due_date}}', formatDate(client.dueDate, lang))
    .replaceAll('{{month}}', formatMonth(client.dueDate, lang));
}

export const TEMPLATE_VARIABLES = ['{{client_name}}', '{{amount}}', '{{due_date}}', '{{month}}'];

type VariantMap = Record<'due5' | 'overdue', Record<Tone, Record<Lang, string>>>;

/**
 * Suggested wordings in natural, polite Tamil (with English equivalents),
 * offered in three tones. Selecting one loads it into the editable template.
 */
export const templateVariants: VariantMap = {
  due5: {
    friendly: {
      ta: 'வணக்கம் {{client_name}} 🙏 அன்பான நினைவூட்டல்: {{month}} மாதத்திற்கான உங்கள் கட்டணம் {{amount}}, {{due_date}} அன்று செலுத்த வேண்டும். இன்னும் 5 நாட்கள் உள்ளன. முன்கூட்டியே செலுத்துவதற்கு நன்றி! 😊',
      en: 'Hello {{client_name}} 🙏 Friendly reminder: your payment of {{amount}} for {{month}} is due on {{due_date}} — 5 days to go. Thank you for paying on time! 😊',
    },
    professional: {
      ta: 'வணக்கம் {{client_name}}. நினைவூட்டல்: {{month}} மாதக் கட்டணம் {{amount}} — கடைசி தேதி {{due_date}} (இன்னும் 5 நாட்கள்). உரிய நேரத்தில் செலுத்துமாறு அன்புடன் கேட்டுக்கொள்கிறோம். நன்றி.',
      en: 'Dear {{client_name}}, this is a reminder that your payment of {{amount}} for {{month}} is due on {{due_date}} (5 days remaining). We kindly ask you to settle it on time. Thank you.',
    },
    strict: {
      ta: '{{client_name}} அவர்களே, {{month}} மாதக் கட்டணம் {{amount}} கண்டிப்பாக {{due_date}}க்குள் செலுத்தப்பட வேண்டும். தாமதம் ஏற்பட்டால் சேவையில் இடையூறு ஏற்படலாம். உடனடி கவனம் தேவை.',
      en: '{{client_name}}, your payment of {{amount}} for {{month}} must be settled by {{due_date}}. Late payment may interrupt the service. Please treat this as urgent.',
    },
  },
  overdue: {
    friendly: {
      ta: 'வணக்கம் {{client_name}} 🙏 {{month}} மாதக் கட்டணம் {{amount}} ({{due_date}}) இன்னும் எங்களுக்கு வந்து சேரவில்லை. மறந்திருந்தால் பரவாயில்லை — உங்களுக்கு வசதியான நேரத்தில் விரைவாகச் செலுத்தவும். நன்றி! 😊',
      en: 'Hello {{client_name}} 🙏 We have not yet received your {{month}} payment of {{amount}} (due {{due_date}}). No worries if it slipped your mind — please settle it soon at your convenience. Thank you! 😊',
    },
    professional: {
      ta: 'வணக்கம் {{client_name}}. {{month}} மாதக் கட்டணம் {{amount}} {{due_date}} அன்று செலுத்தப்பட வேண்டியிருந்தது; இதுவரை பெறப்படவில்லை. தயவுசெய்து விரைவில் செலுத்தவும். ஏதேனும் சிக்கல் இருந்தால் எங்களைத் தொடர்பு கொள்ளவும். நன்றி.',
      en: 'Dear {{client_name}}, your {{month}} payment of {{amount}} was due on {{due_date}} and has not yet been received. Please settle it as soon as possible, and contact us if there is any issue. Thank you.',
    },
    strict: {
      ta: '{{client_name}} அவர்களே, {{month}} மாதக் கட்டணம் {{amount}} ({{due_date}}) தாமதமாகியுள்ளது. 48 மணி நேரத்திற்குள் கட்டாயம் செலுத்தவும்; இல்லையெனில் அடுத்த நடவடிக்கை எடுக்க நேரிடும். இது இறுதி நினைவூட்டல்.',
      en: '{{client_name}}, your {{month}} payment of {{amount}} (due {{due_date}}) is now overdue. It must be settled within 48 hours, otherwise further action will follow. This is a final reminder.',
    },
  },
};

export const defaultTemplates = {
  due5: templateVariants.due5.friendly.ta,
  overdue: templateVariants.overdue.professional.ta,
};

/** Picks the right template for the client's current state and renders it. */
export function buildMessage(client: ClientView, settings: Settings): string {
  const template = client.status === 'overdue' ? settings.templateOverdue : settings.templateDue5;
  return renderTemplate(template, client, settings);
}

/**
 * Normalises a phone number to international digits.
 * "06 12 34 56 78" with country code "33" → "33612345678".
 */
export function normalisePhone(phone: string, countryCode: string): string {
  let digits = phone.replace(/\D/g, '');
  if (digits.startsWith('00')) digits = digits.slice(2);
  const cc = countryCode.replace(/\D/g, '');
  if (digits.startsWith('0') && cc) digits = cc + digits.slice(1);
  return digits;
}

export function whatsappUrl(client: ClientView, settings: Settings): string {
  const phone = normalisePhone(client.phone, settings.countryCode);
  return `https://wa.me/${phone}?text=${encodeURIComponent(buildMessage(client, settings))}`;
}

/**
 * Viber deep link. Viber does not support pre-filled text, so the app copies
 * the message to the clipboard right before opening the chat.
 */
export function viberUrl(client: ClientView, settings: Settings): string {
  const phone = normalisePhone(client.phone, settings.countryCode);
  return `viber://chat?number=%2B${phone}`;
}
