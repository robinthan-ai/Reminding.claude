import type { Client, ClientView, ComputedStatus, Lang } from '../types';

/**
 * Returns the due date for a given month, clamping the due day to the length
 * of that month (dueDay 31 → 30 June, 28/29 February, etc.).
 */
export function clampedDueDate(dueDay: number, year: number, monthIndex: number): Date {
  const lastDay = new Date(year, monthIndex + 1, 0).getDate();
  return new Date(year, monthIndex, Math.min(dueDay, lastDay));
}

/** "2026-07" style key identifying a monthly payment cycle. */
export function periodKey(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
}

export function startOfDay(d: Date): Date {
  const copy = new Date(d);
  copy.setHours(0, 0, 0, 0);
  return copy;
}

/** Whole days from `from` to `to` (date-only, negative if `to` is in the past). */
export function diffDays(from: Date, to: Date): number {
  return Math.round((startOfDay(to).getTime() - startOfDay(from).getTime()) / 86400000);
}

/** "2026-07-02" key for daily reminder dismissals. */
export function todayKey(d: Date = new Date()): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(
    d.getDate()
  ).padStart(2, '0')}`;
}

/**
 * The heart of the automatic reminder system.
 *
 * Every client only stores a due DAY (1-31). Each month the app derives the
 * concrete due date on its own:
 *   - unpaid this month  → this month's due date drives the status
 *   - paid this month    → the cycle rolls over and the NEXT month's due date
 *                          is shown; on the 1st of the next month the status
 *                          automatically returns to "pending"
 *
 * Nothing is ever updated manually.
 */
export function computeView(client: Client, now: Date = new Date()): ClientView {
  const today = startOfDay(now);
  const year = today.getFullYear();
  const month = today.getMonth();
  const currentPeriod = periodKey(today);

  if (client.lastPaidPeriod === currentPeriod) {
    const nextDue = clampedDueDate(client.dueDay, year, month + 1);
    return {
      ...client,
      status: 'paid',
      dueDate: nextDue,
      daysLeft: diffDays(today, nextDue),
    };
  }

  const dueDate = clampedDueDate(client.dueDay, year, month);
  const daysLeft = diffDays(today, dueDate);
  const status: ComputedStatus = daysLeft < 0 ? 'overdue' : daysLeft <= 5 ? 'dueSoon' : 'pending';
  return { ...client, status, dueDate, daysLeft };
}

const localeOf = (lang: Lang) => (lang === 'ta' ? 'ta-IN' : 'en-GB');

export function formatDate(d: Date, lang: Lang): string {
  return new Intl.DateTimeFormat(localeOf(lang), {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  }).format(d);
}

export function formatMonth(d: Date, lang: Lang): string {
  return new Intl.DateTimeFormat(localeOf(lang), { month: 'long' }).format(d);
}

export function formatMonthYear(d: Date, lang: Lang): string {
  return new Intl.DateTimeFormat(localeOf(lang), { month: 'long', year: 'numeric' }).format(d);
}

export function formatShortDate(d: Date, lang: Lang): string {
  return new Intl.DateTimeFormat(localeOf(lang), { day: 'numeric', month: 'short' }).format(d);
}

export function formatWeekday(d: Date, lang: Lang): string {
  return new Intl.DateTimeFormat(localeOf(lang), { weekday: 'short' }).format(d);
}
