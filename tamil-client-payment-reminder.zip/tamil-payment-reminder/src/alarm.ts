/**
 * Alarm engine.
 *
 * The alarm behaves like a real alarm clock: a loud two-tone ring that repeats
 * (with vibration on supported phones) until the user stops it. Sound is
 * generated with the Web Audio API so it works fully offline with no audio
 * files. Browsers only allow audio after a user gesture, so the engine also
 * resumes itself on the first tap/click if it was started automatically.
 */

let audioCtx: AudioContext | null = null;
let ringTimer: number | null = null;
let gestureListenerAttached = false;

function ringOnce() {
  if (!audioCtx || audioCtx.state !== 'running') return;
  const now = audioCtx.currentTime;
  // Classic alarm pattern: four short high/low beeps.
  const pattern = [880, 660, 880, 660];
  pattern.forEach((freq, i) => {
    const osc = audioCtx!.createOscillator();
    const gain = audioCtx!.createGain();
    osc.type = 'square';
    osc.frequency.value = freq;
    const start = now + i * 0.28;
    gain.gain.setValueAtTime(0.0001, start);
    gain.gain.exponentialRampToValueAtTime(0.5, start + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.0001, start + 0.22);
    osc.connect(gain);
    gain.connect(audioCtx!.destination);
    osc.start(start);
    osc.stop(start + 0.24);
  });
  if ('vibrate' in navigator) {
    try {
      navigator.vibrate([250, 120, 250, 120, 250]);
    } catch {
      /* unsupported */
    }
  }
}

function resumeOnGesture() {
  if (gestureListenerAttached) return;
  gestureListenerAttached = true;
  const resume = () => {
    audioCtx?.resume().catch(() => undefined);
    window.removeEventListener('pointerdown', resume);
    window.removeEventListener('keydown', resume);
    gestureListenerAttached = false;
  };
  window.addEventListener('pointerdown', resume);
  window.addEventListener('keydown', resume);
}

export function startAlarm(): void {
  if (ringTimer !== null) return;
  try {
    audioCtx = new AudioContext();
    if (audioCtx.state === 'suspended') {
      audioCtx.resume().catch(() => undefined);
      resumeOnGesture();
    }
  } catch {
    audioCtx = null;
  }
  ringOnce();
  ringTimer = window.setInterval(ringOnce, 1700);
}

export function stopAlarm(): void {
  if (ringTimer !== null) {
    clearInterval(ringTimer);
    ringTimer = null;
  }
  if (audioCtx) {
    audioCtx.close().catch(() => undefined);
    audioCtx = null;
  }
  if ('vibrate' in navigator) {
    try {
      navigator.vibrate(0);
    } catch {
      /* unsupported */
    }
  }
}

export function isAlarmRunning(): boolean {
  return ringTimer !== null;
}

/* ---------- Browser notifications ---------- */

export function notificationPermission(): NotificationPermission | 'unsupported' {
  return 'Notification' in window ? Notification.permission : 'unsupported';
}

export async function requestNotificationPermission(): Promise<NotificationPermission | 'unsupported'> {
  if (!('Notification' in window)) return 'unsupported';
  return Notification.requestPermission();
}

export async function notify(title: string, body: string): Promise<void> {
  if (!('Notification' in window) || Notification.permission !== 'granted') return;
  const options: NotificationOptions & { vibrate?: number[]; renotify?: boolean } = {
    body,
    icon: '/icons/icon-192.png',
    badge: '/icons/icon-192.png',
    tag: 'tcpr-reminder',
    renotify: true,
    vibrate: [300, 150, 300, 150, 300],
  };
  try {
    const registration = await navigator.serviceWorker?.getRegistration();
    if (registration) {
      await registration.showNotification(title, options);
      return;
    }
  } catch {
    /* fall through to plain Notification */
  }
  try {
    new Notification(title, options);
  } catch {
    /* unsupported */
  }
}
