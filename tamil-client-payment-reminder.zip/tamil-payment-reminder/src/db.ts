import type { Client } from './types';

const DB_NAME = 'tcpr-db';
const DB_VERSION = 1;

export const STORE_CLIENTS = 'clients';
export const STORE_KV = 'kv';
export const STORE_DISMISS = 'dismissals';

let dbPromise: Promise<IDBDatabase> | null = null;

export function getDB(): Promise<IDBDatabase> {
  if (!dbPromise) {
    dbPromise = new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains(STORE_CLIENTS)) {
          db.createObjectStore(STORE_CLIENTS, { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains(STORE_KV)) {
          db.createObjectStore(STORE_KV);
        }
        if (!db.objectStoreNames.contains(STORE_DISMISS)) {
          db.createObjectStore(STORE_DISMISS);
        }
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }
  return dbPromise;
}

function requestToPromise<T>(req: IDBRequest<T>): Promise<T> {
  return new Promise((resolve, reject) => {
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function store(name: string, mode: IDBTransactionMode): Promise<IDBObjectStore> {
  const db = await getDB();
  return db.transaction(name, mode).objectStore(name);
}

/* ---------- Clients ---------- */

export async function getAllClients(): Promise<Client[]> {
  const s = await store(STORE_CLIENTS, 'readonly');
  const all = await requestToPromise(s.getAll());
  return (all as Client[]).map((c) => ({
    ...c,
    paidHistory: c.paidHistory ?? [],
    notes: c.notes ?? '',
  }));
}

export async function putClient(client: Client): Promise<void> {
  const s = await store(STORE_CLIENTS, 'readwrite');
  await requestToPromise(s.put(client));
}

export async function putClients(clients: Client[]): Promise<void> {
  const db = await getDB();
  const tx = db.transaction(STORE_CLIENTS, 'readwrite');
  const s = tx.objectStore(STORE_CLIENTS);
  clients.forEach((c) => s.put(c));
  await new Promise<void>((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function deleteClient(id: string): Promise<void> {
  const s = await store(STORE_CLIENTS, 'readwrite');
  await requestToPromise(s.delete(id));
}

/* ---------- Key-value (settings) ---------- */

export async function kvGet<T>(key: string): Promise<T | undefined> {
  const s = await store(STORE_KV, 'readonly');
  return requestToPromise(s.get(key)) as Promise<T | undefined>;
}

export async function kvSet(key: string, value: unknown): Promise<void> {
  const s = await store(STORE_KV, 'readwrite');
  await requestToPromise(s.put(value, key));
}

/* ---------- Daily reminder dismissals ---------- */

export async function isDismissed(key: string): Promise<boolean> {
  const s = await store(STORE_DISMISS, 'readonly');
  const value = await requestToPromise(s.get(key));
  return value === true;
}

export async function setDismissed(key: string): Promise<void> {
  const s = await store(STORE_DISMISS, 'readwrite');
  await requestToPromise(s.put(true, key));
}

/** Remove dismissal keys older than ~40 days so the store stays small. */
export async function pruneDismissals(): Promise<void> {
  const s = await store(STORE_DISMISS, 'readwrite');
  const keys = (await requestToPromise(s.getAllKeys())) as string[];
  const cutoff = Date.now() - 40 * 86400000;
  for (const key of keys) {
    const datePart = key.split(':').pop();
    if (!datePart) continue;
    const time = new Date(datePart).getTime();
    if (!Number.isNaN(time) && time < cutoff) s.delete(key);
  }
}
