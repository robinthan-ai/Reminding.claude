import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';
import './index.css';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>
);

/* Register the service worker (offline shell + notifications). */
if ('serviceWorker' in navigator) {
  window.addEventListener('load', async () => {
    try {
      const registration = await navigator.serviceWorker.register('/sw.js');
      // Periodic background sync (Android / Chromium installed PWAs): lets the
      // app check due payments roughly twice a day even when it is closed.
      try {
        const permissions = navigator.permissions as {
          query(options: { name: string }): Promise<{ state: string }>;
        };
        const status = await permissions.query({ name: 'periodic-background-sync' });
        const periodicSync = (
          registration as unknown as {
            periodicSync?: { register(tag: string, options: { minInterval: number }): Promise<void> };
          }
        ).periodicSync;
        if (status.state === 'granted' && periodicSync) {
          await periodicSync.register('tcpr-check', { minInterval: 12 * 60 * 60 * 1000 });
        }
      } catch {
        /* periodic background sync unsupported — the in-app checker still runs */
      }
    } catch {
      /* service worker unavailable (e.g. dev over http) */
    }
  });
}
