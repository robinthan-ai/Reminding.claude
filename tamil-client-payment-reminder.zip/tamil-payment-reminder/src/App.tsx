import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  BarChart3,
  Calendar as CalendarIcon,
  LayoutDashboard,
  MessageSquareText,
  Plus,
  Settings as SettingsIcon,
  Users,
} from 'lucide-react';
import type {
  Client,
  ClientFilter,
  ClientView,
  Reminder,
  ReminderType,
  Settings,
  Tab,
} from './types';
import { translator } from './i18n';
import {
  deleteClient,
  getAllClients,
  isDismissed,
  kvGet,
  kvSet,
  pruneDismissals,
  putClient,
  putClients,
  setDismissed,
} from './db';
import { computeView, periodKey, todayKey } from './utils/dates';
import { buildMessage, defaultTemplates, viberUrl, whatsappUrl } from './utils/messages';
import {
  isAlarmRunning,
  notificationPermission,
  notify,
  requestNotificationPermission,
  startAlarm,
  stopAlarm,
} from './alarm';
import Dashboard from './components/Dashboard';
import Clients from './components/Clients';
import ClientForm from './components/ClientForm';
import CalendarView from './components/CalendarView';
import Reports from './components/Reports';
import Templates from './components/Templates';
import SettingsPanel from './components/SettingsPanel';
import AlarmOverlay from './components/AlarmOverlay';

const DEFAULT_SETTINGS: Settings = {
  language: 'ta',
  theme: 'light',
  currency: '€',
  countryCode: '33',
  templateDue5: defaultTemplates.due5,
  templateOverdue: defaultTemplates.overdue,
};

function reminderTypeFor(view: ClientView): ReminderType | null {
  if (view.status === 'overdue') return 'overdue';
  if (view.status === 'paid') return null;
  if (view.daysLeft === 0) return 'dueToday';
  if (view.daysLeft === 5) return 'due5';
  return null;
}

export default function App() {
  const [settings, setSettings] = useState<Settings | null>(null);
  const [clients, setClients] = useState<Client[]>([]);
  const [tab, setTab] = useState<Tab>('dashboard');
  const [clientFilter, setClientFilter] = useState<ClientFilter>('all');
  const [editing, setEditing] = useState<Client | 'new' | null>(null);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [reminders, setReminders] = useState<Reminder[]>([]);
  const [alarmOpen, setAlarmOpen] = useState(false);
  const [soundOn, setSoundOn] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const [notifPermission, setNotifPermission] = useState(notificationPermission());
  // Once the user closes the alarm popup, do not reopen it in the same
  // session — persistent dismissals ("today only") live in IndexedDB.
  const alarmSilencedThisSession = useRef(false);
  const notifiedToday = useRef<string>('');

  /* ---------- Bootstrap ---------- */
  useEffect(() => {
    (async () => {
      const stored = await kvGet<Partial<Settings>>('settings');
      setSettings({ ...DEFAULT_SETTINGS, ...(stored ?? {}) });
      setClients(await getAllClients());
      pruneDismissals().catch(() => undefined);
    })();
  }, []);

  /* ---------- Apply theme + language to the document ---------- */
  useEffect(() => {
    if (!settings) return;
    document.documentElement.classList.toggle('dark', settings.theme === 'dark');
    document.documentElement.lang = settings.language;
  }, [settings]);

  const t = useMemo(() => translator(settings?.language ?? 'ta'), [settings?.language]);

  const views = useMemo(() => clients.map((c) => computeView(c)), [clients]);

  const showToast = useCallback((message: string) => {
    setToast(message);
  }, []);

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(null), 2500);
    return () => window.clearTimeout(timer);
  }, [toast]);

  /* ---------- Settings ---------- */
  const updateSettings = useCallback((partial: Partial<Settings>) => {
    setSettings((prev) => {
      const next = { ...(prev ?? DEFAULT_SETTINGS), ...partial };
      kvSet('settings', next).catch(() => undefined);
      return next;
    });
  }, []);

  /* ---------- Clients CRUD ---------- */
  const saveClient = useCallback(async (client: Client) => {
    await putClient(client);
    setClients(await getAllClients());
    setEditing(null);
  }, []);

  const removeClient = useCallback(
    async (client: Client) => {
      if (!window.confirm(`${t('confirmDelete')} — ${client.name}`)) return;
      await deleteClient(client.id);
      setClients(await getAllClients());
    },
    [t]
  );

  const markPaid = useCallback(async (view: ClientView) => {
    const period = periodKey(new Date());
    const client = { ...view } as Client & Partial<ClientView>;
    delete client.status;
    delete client.dueDate;
    delete client.daysLeft;
    const updated: Client = {
      ...client,
      lastPaidPeriod: period,
      paidHistory: [
        ...view.paidHistory.filter((p) => p.period !== period),
        { period, paidAt: Date.now(), amount: view.amount },
      ],
    };
    await putClient(updated);
    // Marking as paid stops today's reminders for this client immediately.
    await setDismissed(`${view.id}:${todayKey()}`);
    setClients(await getAllClients());
  }, []);

  const undoPaid = useCallback(async (view: ClientView) => {
    const period = periodKey(new Date());
    const client = { ...view } as Client & Partial<ClientView>;
    delete client.status;
    delete client.dueDate;
    delete client.daysLeft;
    const updated: Client = {
      ...client,
      lastPaidPeriod: undefined,
      paidHistory: view.paidHistory.filter((p) => p.period !== period),
    };
    await putClient(updated);
    setClients(await getAllClients());
  }, []);

  /* ---------- Messaging ---------- */
  const openWhatsApp = useCallback(
    (view: ClientView) => {
      if (!settings) return;
      window.open(whatsappUrl(view, settings), '_blank', 'noopener');
    },
    [settings]
  );

  const openViber = useCallback(
    async (view: ClientView) => {
      if (!settings) return;
      try {
        await navigator.clipboard.writeText(buildMessage(view, settings));
        showToast(t('messageCopied'));
      } catch {
        /* clipboard unavailable */
      }
      window.location.href = viberUrl(view, settings);
    },
    [settings, showToast, t]
  );

  const copyMessage = useCallback(
    async (view: ClientView) => {
      if (!settings) return;
      try {
        await navigator.clipboard.writeText(buildMessage(view, settings));
        showToast(t('copied'));
      } catch {
        /* clipboard unavailable */
      }
    },
    [settings, showToast, t]
  );

  /* ---------- Automatic reminder engine ----------
   * Runs on load and every minute. For each client it derives this month's
   * due date automatically and raises an alarm at:
   *   - 5 days before the due date
   *   - the due date itself
   *   - every day while overdue, until "Payment received" is clicked
   * A reminder dismissed with "today only" stays quiet until the next day.
   */
  const refreshReminders = useCallback(async () => {
    const today = todayKey();
    const active: Reminder[] = [];
    for (const view of clients.map((c) => computeView(c))) {
      const type = reminderTypeFor(view);
      if (!type) continue;
      if (await isDismissed(`${view.id}:${today}`)) continue;
      active.push({ client: view, type });
    }
    active.sort((a, b) => a.client.daysLeft - b.client.daysLeft);
    setReminders(active);

    if (active.length > 0) {
      if (notifiedToday.current !== today) {
        notifiedToday.current = today;
        const names = active.map((r) => r.client.name).join(', ');
        notify(t('alarmTitle'), names).catch(() => undefined);
      }
      if (!alarmSilencedThisSession.current && !alarmOpen) {
        setAlarmOpen(true);
        startAlarm();
        setSoundOn(true);
      }
    } else {
      setAlarmOpen(false);
      if (isAlarmRunning()) {
        stopAlarm();
        setSoundOn(false);
      }
    }
  }, [clients, t, alarmOpen]);

  useEffect(() => {
    if (!settings) return;
    refreshReminders();
    const interval = window.setInterval(refreshReminders, 60_000);
    return () => window.clearInterval(interval);
  }, [settings, refreshReminders]);

  const dismissToday = useCallback(
    async (view: ClientView) => {
      await setDismissed(`${view.id}:${todayKey()}`);
      await refreshReminders();
    },
    [refreshReminders]
  );

  const snoozeAllToday = useCallback(async () => {
    const today = todayKey();
    await Promise.all(reminders.map((r) => setDismissed(`${r.client.id}:${today}`)));
    stopAlarm();
    setSoundOn(false);
    setAlarmOpen(false);
    await refreshReminders();
  }, [reminders, refreshReminders]);

  const closeAlarm = useCallback(() => {
    stopAlarm();
    setSoundOn(false);
    setAlarmOpen(false);
    alarmSilencedThisSession.current = true;
  }, []);

  const toggleAlarmSound = useCallback(() => {
    if (isAlarmRunning()) {
      stopAlarm();
      setSoundOn(false);
    } else {
      startAlarm();
      setSoundOn(true);
    }
  }, []);

  const enableNotifications = useCallback(async () => {
    const result = await requestNotificationPermission();
    setNotifPermission(result);
  }, []);

  /* ---------- Export / import ---------- */
  const exportData = useCallback(() => {
    if (!settings) return;
    const payload = JSON.stringify({ version: 1, exportedAt: new Date().toISOString(), settings, clients }, null, 2);
    const blob = new Blob([payload], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `payment-reminder-backup-${todayKey()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }, [settings, clients]);

  const importData = useCallback(
    async (file: File) => {
      try {
        const parsed = JSON.parse(await file.text()) as {
          settings?: Partial<Settings>;
          clients?: Client[];
        };
        if (!Array.isArray(parsed.clients)) throw new Error('invalid');
        const imported: Client[] = parsed.clients
          .filter((c) => c && typeof c.name === 'string' && typeof c.dueDay === 'number')
          .map((c) => ({
            id: typeof c.id === 'string' ? c.id : crypto.randomUUID(),
            name: c.name,
            phone: String(c.phone ?? ''),
            amount: Number(c.amount) || 0,
            dueDay: Math.min(31, Math.max(1, Math.round(c.dueDay))),
            notes: String(c.notes ?? ''),
            lastPaidPeriod: typeof c.lastPaidPeriod === 'string' ? c.lastPaidPeriod : undefined,
            paidHistory: Array.isArray(c.paidHistory) ? c.paidHistory : [],
            createdAt: Number(c.createdAt) || Date.now(),
          }));
        await putClients(imported);
        if (parsed.settings) updateSettings(parsed.settings);
        setClients(await getAllClients());
        showToast(t('importDone'));
      } catch {
        showToast(t('importError'));
      }
    },
    [showToast, t, updateSettings]
  );

  if (!settings) return null;

  const sampleView = views.length > 0 ? views[0] : null;

  const tabs: { key: Tab; label: string; icon: typeof Users }[] = [
    { key: 'dashboard', label: t('dashboard'), icon: LayoutDashboard },
    { key: 'clients', label: t('clients'), icon: Users },
    { key: 'calendar', label: t('calendar'), icon: CalendarIcon },
    { key: 'reports', label: t('reports'), icon: BarChart3 },
    { key: 'templates', label: t('templates'), icon: MessageSquareText },
  ];

  return (
    <div className="min-h-dvh bg-slate-50 font-sans text-peacock-950 dark:bg-peacock-950 dark:text-white">
      <header className="sticky top-0 z-20 border-b border-slate-900/5 bg-white/80 backdrop-blur-md dark:border-white/5 dark:bg-peacock-950/80">
        <div className="mx-auto flex max-w-2xl items-center justify-between px-4 py-3">
          <h1 className="font-display text-xl font-extrabold tracking-tight text-peacock-800 dark:text-white">
            {t('appName')}
            <span className="ml-1.5 inline-block h-2 w-2 rounded-full bg-manjal-500 align-middle" />
          </h1>
          <button
            onClick={() => setSettingsOpen(true)}
            aria-label={t('settings')}
            className="rounded-full p-2.5 text-slate-500 transition hover:bg-slate-100 active:scale-90 dark:text-slate-300 dark:hover:bg-white/5"
          >
            <SettingsIcon size={21} />
          </button>
        </div>
      </header>

      <main className="mx-auto max-w-2xl px-4 pb-28 pt-4">
        {tab === 'dashboard' && (
          <Dashboard
            views={views}
            reminders={reminders}
            settings={settings}
            t={t}
            notifPermission={notifPermission}
            onEnableNotifications={enableNotifications}
            onGoClients={(filter) => {
              setClientFilter(filter);
              setTab('clients');
            }}
            onMarkPaid={markPaid}
            onWhatsApp={openWhatsApp}
          />
        )}
        {tab === 'clients' && (
          <Clients
            views={views}
            settings={settings}
            t={t}
            filter={clientFilter}
            onFilterChange={setClientFilter}
            onEdit={(client) => setEditing(client)}
            onDelete={removeClient}
            onMarkPaid={markPaid}
            onUndoPaid={undoPaid}
            onWhatsApp={openWhatsApp}
            onViber={openViber}
            onCopyMessage={copyMessage}
          />
        )}
        {tab === 'calendar' && <CalendarView views={views} settings={settings} t={t} />}
        {tab === 'reports' && <Reports clients={clients} views={views} settings={settings} t={t} />}
        {tab === 'templates' && (
          <Templates settings={settings} t={t} sample={sampleView} onSave={updateSettings} onToast={showToast} />
        )}
      </main>

      {(tab === 'dashboard' || tab === 'clients') && (
        <button
          onClick={() => setEditing('new')}
          aria-label={t('addClient')}
          className="fixed bottom-24 right-4 z-30 grid h-14 w-14 place-items-center rounded-2xl bg-manjal-500 text-peacock-950 shadow-lg transition hover:bg-manjal-400 active:scale-90"
        >
          <Plus size={26} />
        </button>
      )}

      <nav className="fixed inset-x-0 bottom-0 z-20 border-t border-slate-900/5 bg-white/90 backdrop-blur-md dark:border-white/5 dark:bg-peacock-950/90">
        <div className="mx-auto flex max-w-2xl justify-around px-2 pb-[max(0.5rem,env(safe-area-inset-bottom))] pt-1.5">
          {tabs.map(({ key, label, icon: Icon }) => {
            const active = tab === key;
            return (
              <button
                key={key}
                onClick={() => setTab(key)}
                className="flex min-w-0 flex-1 flex-col items-center gap-0.5 rounded-2xl py-1.5 transition active:scale-90"
              >
                <span
                  className={`grid h-8 w-14 place-items-center rounded-full transition ${
                    active
                      ? 'bg-peacock-100 text-peacock-700 dark:bg-peacock-500/20 dark:text-peacock-300'
                      : 'text-slate-400 dark:text-slate-500'
                  }`}
                >
                  <Icon size={20} />
                </span>
                <span
                  className={`truncate text-[11px] font-semibold ${
                    active ? 'text-peacock-700 dark:text-peacock-300' : 'text-slate-400 dark:text-slate-500'
                  }`}
                >
                  {label}
                </span>
              </button>
            );
          })}
        </div>
      </nav>

      {editing !== null && (
        <ClientForm
          client={editing === 'new' ? null : editing}
          settings={settings}
          t={t}
          onSave={saveClient}
          onClose={() => setEditing(null)}
        />
      )}

      {settingsOpen && (
        <SettingsPanel
          settings={settings}
          t={t}
          notifPermission={notifPermission}
          onUpdate={updateSettings}
          onEnableNotifications={enableNotifications}
          onExport={exportData}
          onImport={importData}
          onClose={() => setSettingsOpen(false)}
        />
      )}

      {alarmOpen && reminders.length > 0 && (
        <AlarmOverlay
          reminders={reminders}
          settings={settings}
          t={t}
          soundOn={soundOn}
          onToggleSound={toggleAlarmSound}
          onClose={closeAlarm}
          onSnoozeAll={snoozeAllToday}
          onDismissToday={dismissToday}
          onMarkPaid={markPaid}
          onWhatsApp={openWhatsApp}
        />
      )}

      {toast && (
        <div className="fixed inset-x-0 bottom-24 z-50 flex justify-center px-4">
          <p className="rounded-full bg-peacock-900 px-5 py-2.5 text-sm font-semibold text-white shadow-lg animate-rise dark:bg-white dark:text-peacock-950">
            {toast}
          </p>
        </div>
      )}
    </div>
  );
}
