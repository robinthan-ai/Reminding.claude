import { useMemo, useState } from 'react';
import {
  Check,
  ChevronDown,
  Copy,
  MessageCircle,
  Pencil,
  Phone,
  RotateCcw,
  Search,
  Send,
  Trash2,
} from 'lucide-react';
import type { Client, ClientFilter, ClientView, Settings } from '../types';
import type { Translator } from '../i18n';
import { formatDate } from '../utils/dates';
import { buildMessage } from '../utils/messages';
import { initials, money, statusChip, statusLabelKey } from '../utils/ui';

interface Props {
  views: ClientView[];
  settings: Settings;
  t: Translator;
  filter: ClientFilter;
  onFilterChange: (f: ClientFilter) => void;
  onEdit: (client: Client) => void;
  onDelete: (client: Client) => void;
  onMarkPaid: (client: ClientView) => void;
  onUndoPaid: (client: ClientView) => void;
  onWhatsApp: (client: ClientView) => void;
  onViber: (client: ClientView) => void;
  onCopyMessage: (client: ClientView) => void;
}

const FILTERS: ClientFilter[] = ['all', 'today', 'week', 'overdue', 'pending', 'paid'];

function matchesFilter(view: ClientView, filter: ClientFilter): boolean {
  switch (filter) {
    case 'all':
      return true;
    case 'paid':
      return view.status === 'paid';
    case 'pending':
      return view.status === 'pending';
    case 'overdue':
      return view.status === 'overdue';
    case 'today':
      return view.status !== 'paid' && view.daysLeft === 0;
    case 'week':
      return view.status !== 'paid' && view.daysLeft >= 0 && view.daysLeft <= 7;
  }
}

export default function Clients({
  views,
  settings,
  t,
  filter,
  onFilterChange,
  onEdit,
  onDelete,
  onMarkPaid,
  onUndoPaid,
  onWhatsApp,
  onViber,
  onCopyMessage,
}: Props) {
  const [query, setQuery] = useState('');
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const filterLabel: Record<ClientFilter, string> = {
    all: t('filterAll'),
    paid: t('filterPaid'),
    pending: t('filterPending'),
    overdue: t('filterOverdue'),
    week: t('filterWeek'),
    today: t('filterToday'),
  };

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return views
      .filter((v) => matchesFilter(v, filter))
      .filter((v) => !q || v.name.toLowerCase().includes(q) || v.phone.includes(q))
      .sort((a, b) => a.daysLeft - b.daysLeft);
  }, [views, filter, query]);

  return (
    <div className="space-y-3">
      <label className="flex items-center gap-2 rounded-full bg-white px-4 py-2.5 shadow-sm ring-1 ring-slate-900/5 focus-within:ring-2 focus-within:ring-peacock-500 dark:bg-peacock-900/60 dark:ring-white/10">
        <Search size={18} className="shrink-0 text-slate-400" />
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder={t('search')}
          className="w-full bg-transparent text-sm text-peacock-950 outline-none placeholder:text-slate-400 dark:text-white"
        />
      </label>

      <div className="flex gap-2 overflow-x-auto pb-1 [-ms-overflow-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
        {FILTERS.map((f) => (
          <button
            key={f}
            onClick={() => onFilterChange(f)}
            className={`shrink-0 rounded-full px-4 py-1.5 text-sm font-semibold transition active:scale-95 ${
              filter === f
                ? 'bg-peacock-700 text-white shadow-sm'
                : 'bg-white text-slate-600 ring-1 ring-slate-900/10 dark:bg-peacock-900/60 dark:text-slate-300 dark:ring-white/10'
            }`}
          >
            {filterLabel[f]}
          </button>
        ))}
      </div>

      {views.length === 0 ? (
        <p className="rounded-2xl bg-white p-6 text-center text-sm text-slate-500 shadow-sm ring-1 ring-slate-900/5 dark:bg-peacock-900/60 dark:text-slate-400 dark:ring-white/10">
          {t('emptyClients')}
        </p>
      ) : filtered.length === 0 ? (
        <p className="rounded-2xl bg-white p-6 text-center text-sm text-slate-500 shadow-sm ring-1 ring-slate-900/5 dark:bg-peacock-900/60 dark:text-slate-400 dark:ring-white/10">
          {t('noResults')}
        </p>
      ) : (
        <ul className="space-y-3 pb-24">
          {filtered.map((client) => {
            const expanded = expandedId === client.id;
            return (
              <li
                key={client.id}
                className="overflow-hidden rounded-3xl bg-white shadow-sm ring-1 ring-slate-900/5 animate-rise dark:bg-peacock-900/60 dark:ring-white/10"
              >
                <button
                  onClick={() => setExpandedId(expanded ? null : client.id)}
                  className="flex w-full items-center gap-3 p-4 text-left"
                >
                  <span className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-peacock-100 font-display text-lg font-bold text-peacock-700 dark:bg-peacock-500/15 dark:text-peacock-300">
                    {initials(client.name)}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-display text-base font-bold text-peacock-950 dark:text-white">
                      {client.name}
                    </p>
                    <p className="flex items-center gap-1 text-xs text-slate-500 dark:text-slate-400">
                      <Phone size={12} /> {client.phone}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="font-display text-base font-bold text-peacock-700 dark:text-manjal-400">
                      {money(client.amount, settings.currency)}
                      <span className="text-xs font-medium text-slate-400"> {t('perMonth')}</span>
                    </p>
                    <span
                      className={`inline-block rounded-full px-2.5 py-0.5 text-xs font-semibold ${statusChip[client.status]}`}
                    >
                      {t(statusLabelKey[client.status])}
                      {client.status === 'overdue' && ` · ${Math.abs(client.daysLeft)} ${t('daysLateLabel')}`}
                      {client.status === 'dueSoon' &&
                        ` · ${client.daysLeft === 0 ? t('todayLabel') : `${client.daysLeft} ${t('daysLeftLabel')}`}`}
                    </span>
                  </div>
                  <ChevronDown
                    size={18}
                    className={`shrink-0 text-slate-400 transition-transform ${expanded ? 'rotate-180' : ''}`}
                  />
                </button>

                {expanded && (
                  <div className="space-y-3 border-t border-slate-100 px-4 pb-4 pt-3 animate-fade dark:border-white/5">
                    <p className="text-sm text-slate-600 dark:text-slate-300">
                      <span className="font-semibold">
                        {client.status === 'paid' ? t('nextDue') : t('dueOn')}:
                      </span>{' '}
                      {formatDate(client.dueDate, settings.language)}
                    </p>
                    {client.notes && (
                      <p className="rounded-xl bg-slate-50 p-3 text-sm text-slate-600 dark:bg-white/5 dark:text-slate-300">
                        {client.notes}
                      </p>
                    )}

                    <div>
                      <p className="mb-1 text-xs font-semibold uppercase tracking-wide text-slate-400">
                        {t('messagePreview')}
                      </p>
                      <p className="whitespace-pre-wrap rounded-xl bg-peacock-50 p-3 text-sm leading-relaxed text-peacock-900 dark:bg-peacock-500/10 dark:text-peacock-100">
                        {buildMessage(client, settings)}
                      </p>
                    </div>

                    <div className="flex flex-wrap gap-2">
                      <button
                        onClick={() => onWhatsApp(client)}
                        className="flex items-center gap-1.5 rounded-full bg-[#25D366] px-3.5 py-2 text-sm font-semibold text-white transition hover:brightness-95 active:scale-95"
                      >
                        <MessageCircle size={16} /> {t('whatsapp')}
                      </button>
                      <button
                        onClick={() => onViber(client)}
                        className="flex items-center gap-1.5 rounded-full bg-[#7360F2] px-3.5 py-2 text-sm font-semibold text-white transition hover:brightness-95 active:scale-95"
                      >
                        <Send size={16} /> {t('viber')}
                      </button>
                      <button
                        onClick={() => onCopyMessage(client)}
                        className="flex items-center gap-1.5 rounded-full border border-slate-300 px-3.5 py-2 text-sm font-semibold text-slate-600 transition hover:bg-slate-100 active:scale-95 dark:border-slate-600 dark:text-slate-300 dark:hover:bg-white/5"
                      >
                        <Copy size={16} /> {t('copyMessage')}
                      </button>
                    </div>

                    <div className="flex flex-wrap gap-2 border-t border-slate-100 pt-3 dark:border-white/5">
                      {client.status === 'paid' ? (
                        <button
                          onClick={() => onUndoPaid(client)}
                          className="flex items-center gap-1.5 rounded-full border border-slate-300 px-3.5 py-2 text-sm font-semibold text-slate-600 transition hover:bg-slate-100 active:scale-95 dark:border-slate-600 dark:text-slate-300 dark:hover:bg-white/5"
                        >
                          <RotateCcw size={16} /> {t('undoPaid')}
                        </button>
                      ) : (
                        <button
                          onClick={() => onMarkPaid(client)}
                          className="flex items-center gap-1.5 rounded-full bg-emerald-600 px-3.5 py-2 text-sm font-semibold text-white transition hover:bg-emerald-700 active:scale-95"
                        >
                          <Check size={16} /> {t('markPaid')}
                        </button>
                      )}
                      <button
                        onClick={() => onEdit(client)}
                        className="flex items-center gap-1.5 rounded-full border border-slate-300 px-3.5 py-2 text-sm font-semibold text-slate-600 transition hover:bg-slate-100 active:scale-95 dark:border-slate-600 dark:text-slate-300 dark:hover:bg-white/5"
                      >
                        <Pencil size={16} /> {t('editClient')}
                      </button>
                      <button
                        onClick={() => onDelete(client)}
                        className="flex items-center gap-1.5 rounded-full border border-rose-300 px-3.5 py-2 text-sm font-semibold text-rose-600 transition hover:bg-rose-50 active:scale-95 dark:border-rose-500/40 dark:text-rose-400 dark:hover:bg-rose-500/10"
                      >
                        <Trash2 size={16} /> {t('delete')}
                      </button>
                    </div>
                  </div>
                )}
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
