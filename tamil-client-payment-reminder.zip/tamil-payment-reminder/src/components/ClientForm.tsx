import { useState } from 'react';
import { X } from 'lucide-react';
import type { Client, Settings } from '../types';
import type { Translator } from '../i18n';

interface Props {
  client: Client | null; // null = new client
  settings: Settings;
  t: Translator;
  onSave: (client: Client) => void;
  onClose: () => void;
}

const inputClass =
  'w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm text-peacock-950 outline-none transition focus:border-peacock-500 focus:ring-2 focus:ring-peacock-500/30 dark:border-slate-700 dark:bg-peacock-950 dark:text-white';

export default function ClientForm({ client, settings, t, onSave, onClose }: Props) {
  const [name, setName] = useState(client?.name ?? '');
  const [phone, setPhone] = useState(client?.phone ?? '');
  const [amount, setAmount] = useState(client ? String(client.amount) : '');
  const [dueDay, setDueDay] = useState(client?.dueDay ?? 1);
  const [notes, setNotes] = useState(client?.notes ?? '');
  const [touched, setTouched] = useState(false);

  const nameOk = name.trim().length > 0;
  const phoneOk = phone.replace(/\D/g, '').length >= 6;
  const amountValue = Number(amount.replace(',', '.'));
  const amountOk = Number.isFinite(amountValue) && amountValue > 0;
  const valid = nameOk && phoneOk && amountOk;

  const submit = () => {
    setTouched(true);
    if (!valid) return;
    onSave({
      id: client?.id ?? crypto.randomUUID(),
      name: name.trim(),
      phone: phone.trim(),
      amount: amountValue,
      dueDay,
      notes: notes.trim(),
      lastPaidPeriod: client?.lastPaidPeriod,
      paidHistory: client?.paidHistory ?? [],
      createdAt: client?.createdAt ?? Date.now(),
    });
  };

  const error = (ok: boolean) =>
    touched && !ok ? <p className="mt-1 text-xs font-medium text-rose-600">{t('required')}</p> : null;

  return (
    <div className="fixed inset-0 z-40 flex items-end justify-center bg-peacock-950/60 backdrop-blur-sm animate-fade sm:items-center">
      <div className="flex max-h-[92dvh] w-full max-w-lg flex-col overflow-hidden rounded-t-3xl bg-white shadow-2xl animate-rise dark:bg-peacock-900 sm:rounded-3xl">
        <div className="flex items-center justify-between border-b border-slate-100 px-5 py-4 dark:border-white/5">
          <h2 className="font-display text-xl font-bold text-peacock-950 dark:text-white">
            {client ? t('editClient') : t('addClient')}
          </h2>
          <button onClick={onClose} aria-label={t('close')} className="rounded-full p-2 text-slate-400 hover:bg-slate-100 dark:hover:bg-white/5">
            <X size={20} />
          </button>
        </div>

        <div className="flex-1 space-y-4 overflow-y-auto px-5 py-4">
          <div>
            <label className="mb-1 block text-sm font-semibold text-slate-600 dark:text-slate-300">{t('name')} *</label>
            <input value={name} onChange={(e) => setName(e.target.value)} className={inputClass} autoFocus />
            {error(nameOk)}
          </div>
          <div>
            <label className="mb-1 block text-sm font-semibold text-slate-600 dark:text-slate-300">{t('phone')} *</label>
            <input
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className={inputClass}
              type="tel"
              inputMode="tel"
              placeholder={`+${settings.countryCode} …`}
            />
            {error(phoneOk)}
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="mb-1 block text-sm font-semibold text-slate-600 dark:text-slate-300">
                {t('amount')} ({settings.currency}) *
              </label>
              <input
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className={inputClass}
                type="text"
                inputMode="decimal"
              />
              {error(amountOk)}
            </div>
            <div>
              <label className="mb-1 block text-sm font-semibold text-slate-600 dark:text-slate-300">{t('dueDay')} *</label>
              <select value={dueDay} onChange={(e) => setDueDay(Number(e.target.value))} className={inputClass}>
                {Array.from({ length: 31 }, (_, i) => i + 1).map((d) => (
                  <option key={d} value={d}>
                    {d}
                  </option>
                ))}
              </select>
            </div>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400">{t('dueDayHint')}</p>
          <div>
            <label className="mb-1 block text-sm font-semibold text-slate-600 dark:text-slate-300">{t('notes')}</label>
            <textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={3} className={inputClass} />
          </div>
        </div>

        <div className="flex gap-2 border-t border-slate-100 p-4 dark:border-white/5">
          <button
            onClick={onClose}
            className="flex-1 rounded-full border border-slate-300 py-3 font-semibold text-slate-600 transition active:scale-[0.98] dark:border-slate-600 dark:text-slate-300"
          >
            {t('cancel')}
          </button>
          <button
            onClick={submit}
            className="flex-1 rounded-full bg-peacock-700 py-3 font-display font-bold text-white transition hover:bg-peacock-800 active:scale-[0.98] disabled:opacity-50"
          >
            {t('save')}
          </button>
        </div>
      </div>
    </div>
  );
}
