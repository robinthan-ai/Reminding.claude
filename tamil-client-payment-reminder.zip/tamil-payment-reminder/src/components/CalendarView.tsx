import { useMemo, useState } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import type { ClientView, Settings } from '../types';
import type { Translator } from '../i18n';
import { clampedDueDate, formatMonthYear, periodKey, startOfDay } from '../utils/dates';
import { money, statusDot } from '../utils/ui';

interface Props {
  views: ClientView[];
  settings: Settings;
  t: Translator;
}

export default function CalendarView({ views, settings, t }: Props) {
  const today = startOfDay(new Date());
  const [offset, setOffset] = useState(0);
  const [selectedDay, setSelectedDay] = useState<number | null>(today.getDate());

  const shown = new Date(today.getFullYear(), today.getMonth() + offset, 1);
  const year = shown.getFullYear();
  const month = shown.getMonth();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  // Monday-first grid
  const firstWeekday = (new Date(year, month, 1).getDay() + 6) % 7;
  const isCurrentMonth = offset === 0;

  const byDay = useMemo(() => {
    const map = new Map<number, ClientView[]>();
    for (const view of views) {
      const due = clampedDueDate(view.dueDay, year, month);
      const day = due.getDate();
      const list = map.get(day) ?? [];
      list.push(view);
      map.set(day, list);
    }
    return map;
  }, [views, year, month]);

  const weekdayLabels = useMemo(() => {
    const locale = settings.language === 'ta' ? 'ta-IN' : 'en-GB';
    const fmt = new Intl.DateTimeFormat(locale, { weekday: 'narrow' });
    // 5 Jan 2026 is a Monday
    return Array.from({ length: 7 }, (_, i) => fmt.format(new Date(2026, 0, 5 + i)));
  }, [settings.language]);

  const dotFor = (view: ClientView): string => {
    if (isCurrentMonth) return statusDot[view.status];
    if (offset > 0) return view.lastPaidPeriod === periodKey(shown) ? statusDot.paid : statusDot.pending;
    const period = periodKey(shown);
    const wasPaid = view.paidHistory.some((p) => p.period === period) || view.lastPaidPeriod === period;
    return wasPaid ? statusDot.paid : statusDot.overdue;
  };

  const selectedClients = selectedDay ? (byDay.get(selectedDay) ?? []) : [];

  return (
    <div className="space-y-4">
      <div className="rounded-3xl bg-white p-4 shadow-sm ring-1 ring-slate-900/5 dark:bg-peacock-900/60 dark:ring-white/10">
        <div className="mb-3 flex items-center justify-between">
          <button
            onClick={() => {
              setOffset((o) => o - 1);
              setSelectedDay(null);
            }}
            aria-label="previous month"
            className="rounded-full p-2 text-slate-500 hover:bg-slate-100 dark:hover:bg-white/5"
          >
            <ChevronLeft size={20} />
          </button>
          <h2 className="font-display text-lg font-bold capitalize text-peacock-950 dark:text-white">
            {formatMonthYear(shown, settings.language)}
          </h2>
          <button
            onClick={() => {
              setOffset((o) => o + 1);
              setSelectedDay(null);
            }}
            aria-label="next month"
            className="rounded-full p-2 text-slate-500 hover:bg-slate-100 dark:hover:bg-white/5"
          >
            <ChevronRight size={20} />
          </button>
        </div>

        <div className="grid grid-cols-7 gap-1 text-center">
          {weekdayLabels.map((label, i) => (
            <span key={i} className="pb-1 text-xs font-semibold text-slate-400">
              {label}
            </span>
          ))}
          {Array.from({ length: firstWeekday }).map((_, i) => (
            <span key={`blank-${i}`} />
          ))}
          {Array.from({ length: daysInMonth }, (_, i) => i + 1).map((day) => {
            const clients = byDay.get(day) ?? [];
            const isToday = isCurrentMonth && day === today.getDate();
            const selected = selectedDay === day;
            return (
              <button
                key={day}
                onClick={() => setSelectedDay(day)}
                className={`relative flex aspect-square flex-col items-center justify-center rounded-2xl text-sm font-semibold transition active:scale-90 ${
                  selected
                    ? 'bg-peacock-700 text-white'
                    : isToday
                      ? 'bg-manjal-100 text-manjal-600 ring-2 ring-manjal-400 dark:bg-manjal-500/15 dark:text-manjal-400'
                      : 'text-slate-700 hover:bg-slate-100 dark:text-slate-200 dark:hover:bg-white/5'
                }`}
              >
                {day}
                {clients.length > 0 && (
                  <span className="mt-0.5 flex gap-0.5">
                    {clients.slice(0, 3).map((c) => (
                      <span
                        key={c.id}
                        className={`h-1.5 w-1.5 rounded-full ${selected ? 'bg-white' : dotFor(c)}`}
                      />
                    ))}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {selectedDay !== null && (
        <div className="animate-rise">
          {selectedClients.length === 0 ? (
            <p className="rounded-2xl bg-white p-4 text-sm text-slate-500 shadow-sm ring-1 ring-slate-900/5 dark:bg-peacock-900/60 dark:text-slate-400 dark:ring-white/10">
              {t('noPaymentsThisDay')}
            </p>
          ) : (
            <ul className="divide-y divide-slate-100 overflow-hidden rounded-2xl bg-white shadow-sm ring-1 ring-slate-900/5 dark:divide-white/5 dark:bg-peacock-900/60 dark:ring-white/10">
              {selectedClients.map((client) => (
                <li key={client.id} className="flex items-center gap-3 p-3">
                  <span className={`h-2.5 w-2.5 shrink-0 rounded-full ${dotFor(client)}`} />
                  <p className="min-w-0 flex-1 truncate font-semibold text-peacock-950 dark:text-white">
                    {client.name}
                  </p>
                  <span className="text-sm font-bold text-peacock-700 dark:text-manjal-400">
                    {money(client.amount, settings.currency)}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </div>
  );
}
