import { AlarmClock, AlertTriangle, Bell, Check, CheckCircle2, Clock, MessageCircle, Users } from 'lucide-react';
import type { ClientFilter, ClientView, Reminder, Settings } from '../types';
import type { Translator } from '../i18n';
import { formatShortDate } from '../utils/dates';
import { money, statusDot } from '../utils/ui';

interface Props {
  views: ClientView[];
  reminders: Reminder[];
  settings: Settings;
  t: Translator;
  notifPermission: NotificationPermission | 'unsupported';
  onEnableNotifications: () => void;
  onGoClients: (filter: ClientFilter) => void;
  onMarkPaid: (client: ClientView) => void;
  onWhatsApp: (client: ClientView) => void;
}

export default function Dashboard({
  views,
  reminders,
  settings,
  t,
  notifPermission,
  onEnableNotifications,
  onGoClients,
  onMarkPaid,
  onWhatsApp,
}: Props) {
  const dueSoon = views.filter((v) => v.status === 'dueSoon');
  const overdue = views.filter((v) => v.status === 'overdue');
  const paid = views.filter((v) => v.status === 'paid');
  const upcoming = views
    .filter((v) => v.status !== 'paid' && v.daysLeft >= 0 && v.daysLeft <= 7)
    .sort((a, b) => a.daysLeft - b.daysLeft);

  const stats: {
    key: ClientFilter;
    label: string;
    count: number;
    sum?: number;
    icon: typeof Users;
    accent: string;
  }[] = [
    { key: 'all', label: t('totalClients'), count: views.length, icon: Users, accent: 'text-peacock-600 bg-peacock-100 dark:bg-peacock-500/15 dark:text-peacock-300' },
    { key: 'week', label: t('dueIn5'), count: dueSoon.length, sum: dueSoon.reduce((s, v) => s + v.amount, 0), icon: Clock, accent: 'text-manjal-600 bg-manjal-100 dark:bg-manjal-500/15 dark:text-manjal-400' },
    { key: 'overdue', label: t('overdue'), count: overdue.length, sum: overdue.reduce((s, v) => s + v.amount, 0), icon: AlertTriangle, accent: 'text-rose-600 bg-rose-100 dark:bg-rose-500/15 dark:text-rose-300' },
    { key: 'paid', label: t('paidThisMonth'), count: paid.length, sum: paid.reduce((s, v) => s + v.amount, 0), icon: CheckCircle2, accent: 'text-emerald-600 bg-emerald-100 dark:bg-emerald-500/15 dark:text-emerald-300' },
  ];

  return (
    <div className="space-y-5">
      {notifPermission === 'default' && (
        <button
          onClick={onEnableNotifications}
          className="flex w-full items-center gap-3 rounded-2xl border border-manjal-400/50 bg-manjal-100/70 p-4 text-left text-sm font-semibold text-manjal-600 transition hover:bg-manjal-100 dark:bg-manjal-500/10 dark:text-manjal-400"
        >
          <Bell size={20} className="shrink-0" />
          {t('notifBanner')}
        </button>
      )}

      <div className="grid grid-cols-2 gap-3">
        {stats.map(({ key, label, count, sum, icon: Icon, accent }) => (
          <button
            key={key}
            onClick={() => onGoClients(key)}
            className="rounded-3xl bg-white p-4 text-left shadow-sm ring-1 ring-slate-900/5 transition hover:shadow-md active:scale-[0.98] dark:bg-peacock-900/60 dark:ring-white/10"
          >
            <span className={`inline-grid h-10 w-10 place-items-center rounded-2xl ${accent}`}>
              <Icon size={20} />
            </span>
            <p className="mt-3 font-display text-3xl font-extrabold leading-none text-peacock-950 dark:text-white">
              {count}
            </p>
            <p className="mt-1 text-xs font-medium text-slate-500 dark:text-slate-400">{label}</p>
            {sum !== undefined && sum > 0 && (
              <p className="mt-0.5 text-xs font-semibold text-slate-600 dark:text-slate-300">
                {money(sum, settings.currency)}
              </p>
            )}
          </button>
        ))}
      </div>

      <section>
        <h2 className="mb-2 flex items-center gap-2 font-display text-lg font-bold text-peacock-950 dark:text-white">
          <AlarmClock size={20} className="text-rose-500" />
          {t('todayReminders')}
        </h2>
        {reminders.length === 0 ? (
          <p className="rounded-2xl bg-white p-4 text-sm text-slate-500 shadow-sm ring-1 ring-slate-900/5 dark:bg-peacock-900/60 dark:text-slate-400 dark:ring-white/10">
            {t('noRemindersToday')}
          </p>
        ) : (
          <ul className="space-y-2">
            {reminders.map(({ client, type }) => (
              <li
                key={client.id}
                className="flex items-center gap-3 rounded-2xl bg-white p-3 shadow-sm ring-1 ring-slate-900/5 animate-rise dark:bg-peacock-900/60 dark:ring-white/10"
              >
                <span className={`h-2.5 w-2.5 shrink-0 rounded-full ${statusDot[client.status]}`} />
                <div className="min-w-0 flex-1">
                  <p className="truncate font-semibold text-peacock-950 dark:text-white">{client.name}</p>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    {type === 'due5' ? t('reminder5Banner') : type === 'dueToday' ? t('dueTodayBanner') : t('overdueBanner')}
                  </p>
                </div>
                <span className="text-sm font-bold text-peacock-700 dark:text-manjal-400">
                  {money(client.amount, settings.currency)}
                </span>
                <button
                  onClick={() => onWhatsApp(client)}
                  aria-label={t('whatsapp')}
                  className="grid h-9 w-9 place-items-center rounded-full bg-[#25D366] text-white transition active:scale-90"
                >
                  <MessageCircle size={17} />
                </button>
                <button
                  onClick={() => onMarkPaid(client)}
                  aria-label={t('markPaid')}
                  className="grid h-9 w-9 place-items-center rounded-full bg-emerald-600 text-white transition active:scale-90"
                >
                  <Check size={17} />
                </button>
              </li>
            ))}
          </ul>
        )}
      </section>

      <section>
        <h2 className="mb-2 font-display text-lg font-bold text-peacock-950 dark:text-white">{t('upcoming7')}</h2>
        {upcoming.length === 0 ? (
          <p className="rounded-2xl bg-white p-4 text-sm text-slate-500 shadow-sm ring-1 ring-slate-900/5 dark:bg-peacock-900/60 dark:text-slate-400 dark:ring-white/10">
            {t('nothingUpcoming')}
          </p>
        ) : (
          <ul className="divide-y divide-slate-100 overflow-hidden rounded-2xl bg-white shadow-sm ring-1 ring-slate-900/5 dark:divide-white/5 dark:bg-peacock-900/60 dark:ring-white/10">
            {upcoming.map((client) => (
              <li key={client.id} className="flex items-center gap-3 p-3">
                <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-peacock-100 font-display text-sm font-bold text-peacock-700 dark:bg-peacock-500/15 dark:text-peacock-300">
                  {formatShortDate(client.dueDate, settings.language)}
                </span>
                <div className="min-w-0 flex-1">
                  <p className="truncate font-semibold text-peacock-950 dark:text-white">{client.name}</p>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    {client.daysLeft === 0
                      ? t('todayLabel')
                      : `${client.daysLeft} ${t('daysLeftLabel')}`}
                  </p>
                </div>
                <span className="text-sm font-bold text-peacock-700 dark:text-manjal-400">
                  {money(client.amount, settings.currency)}
                </span>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
