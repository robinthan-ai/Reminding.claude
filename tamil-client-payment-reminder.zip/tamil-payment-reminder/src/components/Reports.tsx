import { useMemo } from 'react';
import type { Client, ClientView, Settings } from '../types';
import type { Translator } from '../i18n';
import { formatMonthYear, periodKey } from '../utils/dates';
import { money } from '../utils/ui';

interface Props {
  clients: Client[];
  views: ClientView[];
  settings: Settings;
  t: Translator;
}

interface Row {
  label: string;
  amount: number;
  count: number;
  bar: string;
  text: string;
}

export default function Reports({ clients, views, settings, t }: Props) {
  const now = new Date();
  const currentPeriod = periodKey(now);

  const { rows, expected } = useMemo(() => {
    const paidViews = views.filter((v) => v.status === 'paid');
    const pendingViews = views.filter((v) => v.status === 'pending' || v.status === 'dueSoon');
    const overdueViews = views.filter((v) => v.status === 'overdue');
    const sum = (list: ClientView[]) => list.reduce((s, v) => s + v.amount, 0);
    const total = sum(views);
    const data: Row[] = [
      { label: t('monthPaid'), amount: sum(paidViews), count: paidViews.length, bar: 'bg-emerald-500', text: 'text-emerald-600 dark:text-emerald-400' },
      { label: t('monthPending'), amount: sum(pendingViews), count: pendingViews.length, bar: 'bg-manjal-500', text: 'text-manjal-600 dark:text-manjal-400' },
      { label: t('monthOverdue'), amount: sum(overdueViews), count: overdueViews.length, bar: 'bg-rose-500', text: 'text-rose-600 dark:text-rose-400' },
    ];
    return { rows: data, expected: total };
  }, [views, t]);

  const history = useMemo(() => {
    const months: { key: string; date: Date; paid: number; count: number }[] = [];
    for (let i = 1; i <= 6; i++) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      months.push({ key: periodKey(d), date: d, paid: 0, count: 0 });
    }
    for (const client of clients) {
      for (const record of client.paidHistory) {
        const entry = months.find((m) => m.key === record.period);
        if (entry && record.period !== currentPeriod) {
          entry.paid += record.amount;
          entry.count += 1;
        }
      }
    }
    return months;
  }, [clients, currentPeriod, now]);

  const maxHistory = Math.max(1, ...history.map((m) => m.paid));

  return (
    <div className="space-y-4">
      <div className="rounded-3xl bg-gradient-to-br from-peacock-700 to-peacock-900 p-5 text-white shadow-sm">
        <p className="text-sm font-medium capitalize text-peacock-100">
          {formatMonthYear(now, settings.language)}
        </p>
        <p className="mt-1 font-display text-3xl font-extrabold">{money(expected, settings.currency)}</p>
        <p className="text-sm text-peacock-200">{t('monthExpected')}</p>
      </div>

      <div className="space-y-4 rounded-3xl bg-white p-5 shadow-sm ring-1 ring-slate-900/5 dark:bg-peacock-900/60 dark:ring-white/10">
        {rows.map((row) => (
          <div key={row.label}>
            <div className="mb-1 flex items-baseline justify-between">
              <span className="text-sm font-semibold text-slate-600 dark:text-slate-300">
                {row.label}
                <span className="ml-2 text-xs font-medium text-slate-400">
                  {row.count} {t('clientsCount')}
                </span>
              </span>
              <span className={`font-display text-base font-bold ${row.text}`}>
                {money(row.amount, settings.currency)}
              </span>
            </div>
            <div className="h-2.5 overflow-hidden rounded-full bg-slate-100 dark:bg-white/5">
              <div
                className={`h-full rounded-full transition-all duration-500 ${row.bar}`}
                style={{ width: expected > 0 ? `${(row.amount / expected) * 100}%` : '0%' }}
              />
            </div>
          </div>
        ))}
      </div>

      <section>
        <h2 className="mb-2 font-display text-lg font-bold text-peacock-950 dark:text-white">{t('history')}</h2>
        <ul className="divide-y divide-slate-100 overflow-hidden rounded-2xl bg-white shadow-sm ring-1 ring-slate-900/5 dark:divide-white/5 dark:bg-peacock-900/60 dark:ring-white/10">
          {history.map((m) => (
            <li key={m.key} className="flex items-center gap-3 p-3">
              <span className="w-28 shrink-0 text-sm font-semibold capitalize text-slate-600 dark:text-slate-300">
                {formatMonthYear(m.date, settings.language)}
              </span>
              <div className="h-2 flex-1 overflow-hidden rounded-full bg-slate-100 dark:bg-white/5">
                <div
                  className="h-full rounded-full bg-emerald-500 transition-all duration-500"
                  style={{ width: `${(m.paid / maxHistory) * 100}%` }}
                />
              </div>
              <span className="w-24 shrink-0 text-right text-sm font-bold text-emerald-600 dark:text-emerald-400">
                {money(m.paid, settings.currency)}
              </span>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}
