import { useEffect, useState } from 'react';
import { RotateCcw, Sparkles } from 'lucide-react';
import type { ClientView, Settings, Tone } from '../types';
import type { Translator } from '../i18n';
import { computeView } from '../utils/dates';
import {
  defaultTemplates,
  renderTemplate,
  TEMPLATE_VARIABLES,
  templateVariants,
} from '../utils/messages';

interface Props {
  settings: Settings;
  t: Translator;
  sample: ClientView | null;
  onSave: (partial: Partial<Settings>) => void;
  onToast: (message: string) => void;
}

const TONES: Tone[] = ['friendly', 'professional', 'strict'];

function fallbackSample(): ClientView {
  return computeView({
    id: 'sample',
    name: 'குமார் / Kumar',
    phone: '0612345678',
    amount: 50,
    dueDay: 25,
    notes: '',
    paidHistory: [],
    createdAt: Date.now(),
  });
}

interface EditorProps {
  kind: 'due5' | 'overdue';
  title: string;
  value: string;
  sample: ClientView;
  settings: Settings;
  t: Translator;
  onChange: (value: string) => void;
  onReset: () => void;
}

function TemplateEditor({ kind, title, value, sample, settings, t, onChange, onReset }: EditorProps) {
  const toneLabel: Record<Tone, string> = {
    friendly: t('friendly'),
    professional: t('professional'),
    strict: t('strict'),
  };

  return (
    <section className="space-y-3 rounded-3xl bg-white p-4 shadow-sm ring-1 ring-slate-900/5 dark:bg-peacock-900/60 dark:ring-white/10">
      <div className="flex items-center justify-between gap-2">
        <h2 className="font-display text-base font-bold text-peacock-950 dark:text-white">{title}</h2>
        <button
          onClick={onReset}
          className="flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-semibold text-slate-500 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-white/5"
        >
          <RotateCcw size={13} /> {t('resetDefault')}
        </button>
      </div>

      <textarea
        value={value}
        onChange={(e) => onChange(e.target.value)}
        rows={5}
        className="w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm leading-relaxed text-peacock-950 outline-none transition focus:border-peacock-500 focus:ring-2 focus:ring-peacock-500/30 dark:border-slate-700 dark:bg-peacock-950 dark:text-white"
      />

      <div>
        <p className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-slate-400">{t('variables')}</p>
        <div className="flex flex-wrap gap-1.5">
          {TEMPLATE_VARIABLES.map((variable) => (
            <button
              key={variable}
              onClick={() => onChange(value + (value.endsWith(' ') || value === '' ? '' : ' ') + variable)}
              className="rounded-full bg-peacock-100 px-2.5 py-1 font-mono text-xs font-semibold text-peacock-700 transition active:scale-95 dark:bg-peacock-500/15 dark:text-peacock-300"
            >
              {variable}
            </button>
          ))}
        </div>
      </div>

      <div>
        <p className="mb-1.5 flex items-center gap-1 text-xs font-semibold uppercase tracking-wide text-slate-400">
          <Sparkles size={13} className="text-manjal-500" /> {t('suggestions')}
        </p>
        <div className="flex flex-wrap gap-1.5">
          {TONES.map((tone) => (
            <button
              key={tone}
              onClick={() => onChange(templateVariants[kind][tone][settings.language])}
              className="rounded-full border border-manjal-400/50 bg-manjal-100/60 px-3 py-1.5 text-xs font-semibold text-manjal-600 transition hover:bg-manjal-100 active:scale-95 dark:bg-manjal-500/10 dark:text-manjal-400"
            >
              {toneLabel[tone]}
            </button>
          ))}
        </div>
      </div>

      <div>
        <p className="mb-1 text-xs font-semibold uppercase tracking-wide text-slate-400">
          {t('preview')} — {t('sampleClient')}
        </p>
        <p className="whitespace-pre-wrap rounded-2xl bg-peacock-50 p-3 text-sm leading-relaxed text-peacock-900 dark:bg-peacock-500/10 dark:text-peacock-100">
          {renderTemplate(value, sample, settings)}
        </p>
      </div>
    </section>
  );
}

export default function Templates({ settings, t, sample, onSave, onToast }: Props) {
  const [due5, setDue5] = useState(settings.templateDue5);
  const [overdue, setOverdue] = useState(settings.templateOverdue);

  useEffect(() => {
    setDue5(settings.templateDue5);
    setOverdue(settings.templateOverdue);
  }, [settings.templateDue5, settings.templateOverdue]);

  const previewClient = sample ?? fallbackSample();
  const dirty = due5 !== settings.templateDue5 || overdue !== settings.templateOverdue;

  return (
    <div className="space-y-4 pb-24">
      <p className="rounded-2xl bg-peacock-100/70 p-3 text-sm text-peacock-800 dark:bg-peacock-500/10 dark:text-peacock-200">
        {t('templatesIntro')}
      </p>

      <TemplateEditor
        kind="due5"
        title={t('due5Template')}
        value={due5}
        sample={previewClient}
        settings={settings}
        t={t}
        onChange={setDue5}
        onReset={() => setDue5(defaultTemplates.due5)}
      />

      <TemplateEditor
        kind="overdue"
        title={t('overdueTemplate')}
        value={overdue}
        sample={{ ...previewClient, status: 'overdue' }}
        settings={settings}
        t={t}
        onChange={setOverdue}
        onReset={() => setOverdue(defaultTemplates.overdue)}
      />

      {dirty && (
        <button
          onClick={() => {
            onSave({ templateDue5: due5, templateOverdue: overdue });
            onToast(t('saved'));
          }}
          className="fixed inset-x-4 bottom-20 z-30 mx-auto max-w-lg rounded-full bg-peacock-700 py-3.5 font-display text-base font-bold text-white shadow-lg transition hover:bg-peacock-800 active:scale-[0.98]"
        >
          {t('save')}
        </button>
      )}
    </div>
  );
}
