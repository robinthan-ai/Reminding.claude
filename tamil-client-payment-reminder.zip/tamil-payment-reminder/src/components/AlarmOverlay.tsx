import { Bell, BellOff, Check, MessageCircle, Volume2, VolumeX, X } from 'lucide-react';
import type { ClientView, Reminder, ReminderType, Settings } from '../types';
import type { Translator } from '../i18n';
import { formatDate } from '../utils/dates';
import { money } from '../utils/ui';

interface Props {
  reminders: Reminder[];
  settings: Settings;
  t: Translator;
  soundOn: boolean;
  onToggleSound: () => void;
  onClose: () => void;
  onSnoozeAll: () => void;
  onDismissToday: (client: ClientView) => void;
  onMarkPaid: (client: ClientView) => void;
  onWhatsApp: (client: ClientView) => void;
}

const typeStyle: Record<ReminderType, string> = {
  due5: 'border-manjal-400/60 bg-manjal-100/60 dark:bg-manjal-500/10',
  dueToday: 'border-peacock-400/60 bg-peacock-100/60 dark:bg-peacock-500/10',
  overdue: 'border-rose-400/60 bg-rose-100/60 dark:bg-rose-500/10',
};

export default function AlarmOverlay({
  reminders,
  settings,
  t,
  soundOn,
  onToggleSound,
  onClose,
  onSnoozeAll,
  onDismissToday,
  onMarkPaid,
  onWhatsApp,
}: Props) {
  const bannerFor = (type: ReminderType) =>
    type === 'due5' ? t('reminder5Banner') : type === 'dueToday' ? t('dueTodayBanner') : t('overdueBanner');

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-peacock-950/70 backdrop-blur-sm animate-fade sm:items-center">
      <div className="flex max-h-[92dvh] w-full max-w-lg flex-col overflow-hidden rounded-t-3xl bg-white shadow-2xl animate-rise dark:bg-peacock-950 sm:rounded-3xl">
        <div className="relative flex flex-col items-center gap-2 bg-gradient-to-b from-rose-600 to-rose-700 px-6 pb-5 pt-6 text-white">
          <button
            onClick={onClose}
            aria-label={t('close')}
            className="absolute right-3 top-3 rounded-full p-2 hover:bg-white/15"
          >
            <X size={20} />
          </button>
          <span className="grid h-16 w-16 place-items-center rounded-full bg-white/15 animate-pulse-ring">
            <Bell size={34} className="animate-bell-ring" />
          </span>
          <h2 className="font-display text-2xl font-bold">{t('alarmTitle')}</h2>
          <button
            onClick={onToggleSound}
            className="flex items-center gap-2 rounded-full bg-white/15 px-4 py-1.5 text-sm font-semibold hover:bg-white/25"
          >
            {soundOn ? <VolumeX size={16} /> : <Volume2 size={16} />}
            {t('stopSound')}
          </button>
        </div>

        <div className="flex-1 space-y-3 overflow-y-auto px-4 py-4">
          {reminders.map(({ client, type }) => (
            <div key={client.id} className={`rounded-2xl border p-4 ${typeStyle[type]}`}>
              <p className="text-xs font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-400">
                {bannerFor(type)}
              </p>
              <div className="mt-1 flex items-baseline justify-between gap-2">
                <p className="font-display text-lg font-bold text-peacock-900 dark:text-peacock-100">
                  {client.name}
                </p>
                <p className="font-display text-lg font-bold text-peacock-700 dark:text-manjal-400">
                  {money(client.amount, settings.currency)}
                </p>
              </div>
              <p className="text-sm text-slate-600 dark:text-slate-300">
                {t('dueOn')}: {formatDate(client.dueDate, settings.language)}
                {client.daysLeft < 0 && (
                  <span className="ml-2 font-semibold text-rose-600 dark:text-rose-400">
                    {Math.abs(client.daysLeft)} {t('daysLateLabel')}
                  </span>
                )}
              </p>
              <div className="mt-3 flex flex-wrap gap-2">
                <button
                  onClick={() => onMarkPaid(client)}
                  className="flex items-center gap-1.5 rounded-full bg-emerald-600 px-3.5 py-2 text-sm font-semibold text-white transition hover:bg-emerald-700 active:scale-95"
                >
                  <Check size={16} /> {t('paymentReceived')}
                </button>
                <button
                  onClick={() => onWhatsApp(client)}
                  className="flex items-center gap-1.5 rounded-full bg-[#25D366] px-3.5 py-2 text-sm font-semibold text-white transition hover:brightness-95 active:scale-95"
                >
                  <MessageCircle size={16} /> {t('whatsapp')}
                </button>
                <button
                  onClick={() => onDismissToday(client)}
                  className="flex items-center gap-1.5 rounded-full border border-slate-300 px-3.5 py-2 text-sm font-semibold text-slate-600 transition hover:bg-slate-100 active:scale-95 dark:border-slate-600 dark:text-slate-300 dark:hover:bg-slate-800"
                >
                  <BellOff size={16} /> {t('dismissToday')}
                </button>
              </div>
            </div>
          ))}
        </div>

        <div className="border-t border-slate-200 p-3 dark:border-slate-800">
          <button
            onClick={onSnoozeAll}
            className="w-full rounded-full bg-peacock-700 py-3 font-display text-base font-bold text-white transition hover:bg-peacock-800 active:scale-[0.98]"
          >
            {t('snoozeAllToday')}
          </button>
        </div>
      </div>
    </div>
  );
}
