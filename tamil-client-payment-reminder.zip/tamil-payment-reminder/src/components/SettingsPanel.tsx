import { useRef } from 'react';
import { Bell, Download, Moon, Sun, Upload, X } from 'lucide-react';
import type { Lang, Settings, Theme } from '../types';
import type { Translator } from '../i18n';

interface Props {
  settings: Settings;
  t: Translator;
  notifPermission: NotificationPermission | 'unsupported';
  onUpdate: (partial: Partial<Settings>) => void;
  onEnableNotifications: () => void;
  onExport: () => void;
  onImport: (file: File) => void;
  onClose: () => void;
}

const inputClass =
  'w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm text-peacock-950 outline-none transition focus:border-peacock-500 focus:ring-2 focus:ring-peacock-500/30 dark:border-slate-700 dark:bg-peacock-950 dark:text-white';

export default function SettingsPanel({
  settings,
  t,
  notifPermission,
  onUpdate,
  onEnableNotifications,
  onExport,
  onImport,
  onClose,
}: Props) {
  const fileRef = useRef<HTMLInputElement>(null);

  const segment = (active: boolean) =>
    `flex flex-1 items-center justify-center gap-1.5 rounded-full py-2.5 text-sm font-semibold transition active:scale-95 ${
      active
        ? 'bg-peacock-700 text-white shadow-sm'
        : 'text-slate-600 dark:text-slate-300'
    }`;

  return (
    <div className="fixed inset-0 z-40 flex items-end justify-center bg-peacock-950/60 backdrop-blur-sm animate-fade sm:items-center">
      <div className="flex max-h-[92dvh] w-full max-w-lg flex-col overflow-hidden rounded-t-3xl bg-white shadow-2xl animate-rise dark:bg-peacock-900 sm:rounded-3xl">
        <div className="flex items-center justify-between border-b border-slate-100 px-5 py-4 dark:border-white/5">
          <h2 className="font-display text-xl font-bold text-peacock-950 dark:text-white">{t('settings')}</h2>
          <button onClick={onClose} aria-label={t('close')} className="rounded-full p-2 text-slate-400 hover:bg-slate-100 dark:hover:bg-white/5">
            <X size={20} />
          </button>
        </div>

        <div className="flex-1 space-y-5 overflow-y-auto px-5 py-4">
          <div>
            <p className="mb-2 text-sm font-semibold text-slate-600 dark:text-slate-300">{t('language')}</p>
            <div className="flex rounded-full bg-slate-100 p-1 dark:bg-white/5">
              {(['ta', 'en'] as Lang[]).map((lang) => (
                <button key={lang} onClick={() => onUpdate({ language: lang })} className={segment(settings.language === lang)}>
                  {lang === 'ta' ? 'தமிழ்' : 'English'}
                </button>
              ))}
            </div>
          </div>

          <div>
            <p className="mb-2 text-sm font-semibold text-slate-600 dark:text-slate-300">{t('theme')}</p>
            <div className="flex rounded-full bg-slate-100 p-1 dark:bg-white/5">
              {(['light', 'dark'] as Theme[]).map((theme) => (
                <button key={theme} onClick={() => onUpdate({ theme })} className={segment(settings.theme === theme)}>
                  {theme === 'light' ? <Sun size={15} /> : <Moon size={15} />}
                  {theme === 'light' ? t('light') : t('dark')}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="mb-1 block text-sm font-semibold text-slate-600 dark:text-slate-300">{t('currency')}</label>
              <input
                value={settings.currency}
                onChange={(e) => onUpdate({ currency: e.target.value })}
                className={inputClass}
              />
            </div>
            <div>
              <label className="mb-1 block text-sm font-semibold text-slate-600 dark:text-slate-300">{t('countryCode')}</label>
              <input
                value={settings.countryCode}
                onChange={(e) => onUpdate({ countryCode: e.target.value.replace(/\D/g, '') })}
                className={inputClass}
                inputMode="numeric"
              />
            </div>
          </div>
          <p className="-mt-3 text-xs text-slate-500 dark:text-slate-400">{t('countryCodeHint')}</p>

          <div>
            <p className="mb-2 text-sm font-semibold text-slate-600 dark:text-slate-300">{t('notifications')}</p>
            {notifPermission === 'granted' ? (
              <p className="rounded-2xl bg-emerald-100 p-3 text-sm font-semibold text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300">
                {t('notifEnabled')}
              </p>
            ) : notifPermission === 'denied' ? (
              <p className="rounded-2xl bg-rose-100 p-3 text-sm font-semibold text-rose-700 dark:bg-rose-500/15 dark:text-rose-300">
                {t('notifBlocked')}
              </p>
            ) : (
              <button
                onClick={onEnableNotifications}
                className="flex w-full items-center justify-center gap-2 rounded-full bg-peacock-700 py-3 font-semibold text-white transition hover:bg-peacock-800 active:scale-[0.98]"
              >
                <Bell size={17} /> {t('enableNotifications')}
              </button>
            )}
          </div>

          <div>
            <p className="mb-2 text-sm font-semibold text-slate-600 dark:text-slate-300">{t('data')}</p>
            <div className="flex gap-2">
              <button
                onClick={onExport}
                className="flex flex-1 items-center justify-center gap-2 rounded-full border border-slate-300 py-3 text-sm font-semibold text-slate-600 transition active:scale-[0.98] dark:border-slate-600 dark:text-slate-300"
              >
                <Download size={16} /> {t('exportData')}
              </button>
              <button
                onClick={() => fileRef.current?.click()}
                className="flex flex-1 items-center justify-center gap-2 rounded-full border border-slate-300 py-3 text-sm font-semibold text-slate-600 transition active:scale-[0.98] dark:border-slate-600 dark:text-slate-300"
              >
                <Upload size={16} /> {t('importData')}
              </button>
              <input
                ref={fileRef}
                type="file"
                accept="application/json"
                className="hidden"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) onImport(file);
                  e.target.value = '';
                }}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
