export type Lang = 'ta' | 'en';
export type Theme = 'light' | 'dark';
export type Tone = 'friendly' | 'professional' | 'strict';

export interface PaymentRecord {
  period: string; // "2026-07"
  paidAt: number; // timestamp
  amount: number;
}

export interface Client {
  id: string;
  name: string;
  phone: string;
  amount: number;
  dueDay: number; // 1-31, automatically clamped to each month's length
  notes: string;
  lastPaidPeriod?: string; // period key of the last paid month, e.g. "2026-07"
  paidHistory: PaymentRecord[];
  createdAt: number;
}

export type ComputedStatus = 'paid' | 'pending' | 'dueSoon' | 'overdue';

/** A client enriched with the automatically computed monthly cycle. */
export interface ClientView extends Client {
  status: ComputedStatus;
  /** The relevant due date: this month's if unpaid, next month's if already paid. */
  dueDate: Date;
  /** Days from today to dueDate (negative = late). */
  daysLeft: number;
}

export type ReminderType = 'due5' | 'dueToday' | 'overdue';

export interface Reminder {
  client: ClientView;
  type: ReminderType;
}

export interface Settings {
  language: Lang;
  theme: Theme;
  currency: string;
  /** Default country calling code used to normalise local numbers, e.g. "33" for France. */
  countryCode: string;
  templateDue5: string;
  templateOverdue: string;
}

export type Tab = 'dashboard' | 'clients' | 'calendar' | 'reports' | 'templates';

export type ClientFilter = 'all' | 'paid' | 'pending' | 'overdue' | 'week' | 'today';
