# தமிழ் வாடிக்கையாளர் கட்டண நினைவூட்டல் — Tamil Client Payment Reminder

PWA moderne (React + TypeScript + Vite + Tailwind CSS) pour gérer les paiements mensuels de tes clients, avec rappels automatiques de type alarme, messages en tamoul et envoi en un clic par WhatsApp / Viber. Fonctionne 100 % hors ligne après la première visite (IndexedDB + Service Worker).

## ✨ Fonctionnalités

- **Tableau de bord** : total clients, échéances à 5 jours, retards, payés, rappels du jour, 7 prochains jours
- **Clients** : nom, téléphone, montant, jour d'échéance (1–31), notes, statut (payé / en attente / retard)
- **Cycle mensuel automatique** : le jour d'échéance (ex. 25) génère automatiquement la prochaine date chaque mois (25 juillet → 25 août). Les jours 29/30/31 sont ajustés automatiquement (février, juin…). Aucune mise à jour manuelle, jamais.
- **Alarme** : popup plein écran + son fort (Web Audio) + vibration + notification navigateur, qui se répète jusqu'à action. Rappel à J−5, le jour J, puis **tous les jours** en cas de retard jusqu'au clic « ✅ Paiement reçu ».
- **Messages tamouls automatiques** : 2 modèles éditables (J−5 et retard) avec variables `{{client_name}}`, `{{amount}}`, `{{due_date}}`, `{{month}}` mises à jour chaque mois, + suggestions en 3 tons (amical 😊, professionnel 💼, strict ⚠️)
- **WhatsApp** : ouvre la discussion avec le message pré-rempli. **Viber** : copie le message puis ouvre la discussion (Viber n'accepte pas le texte pré-rempli)
- **Recherche instantanée + filtres** : payés, en attente, retard, cette semaine, aujourd'hui
- **Calendrier mensuel** avec les dates de paiement
- **Rapports** : montants payés / en attente / en retard du mois + historique 6 mois
- **Stockage IndexedDB hors ligne + export/import JSON**
- **Tamoul par défaut / anglais**, mode sombre/clair, Material Design 3, mobile-first, polices Catamaran + Noto Sans Tamil

## 🚀 Installation locale

```bash
npm install
npm run dev        # développement → http://localhost:5173
npm run build      # vérification TypeScript + build production dans dist/
npm run preview    # tester le build de production
```

Prérequis : Node.js 18+.

## 🌐 Déploiement sur Netlify

### Option A — Depuis Git (recommandé)

1. Pousse ce dossier sur GitHub/GitLab
2. Sur [app.netlify.com](https://app.netlify.com) → **Add new site → Import an existing project**
3. Netlify lit automatiquement `netlify.toml` :
   - Build command : `npm run build`
   - Publish directory : `dist`
4. Deploy — c'est tout.

### Option B — Netlify CLI

```bash
npm install -g netlify-cli
npm run build
netlify deploy --prod --dir=dist
```

Le fichier `netlify.toml` inclut déjà :
- la redirection SPA (`/* → /index.html`)
- `Cache-Control: no-cache` pour `sw.js` (mises à jour du Service Worker fiables)
- cache long pour les assets

## 📱 Installer comme application

Sur le site déployé (HTTPS obligatoire pour les notifications et le Service Worker) :
- **Android / Chrome** : menu ⋮ → « Installer l'application »
- **iPhone / Safari** : Partager → « Sur l'écran d'accueil »

Puis dans l'app : **Réglages ⚙️ → Activer les notifications**.

## ⏰ Comment marchent les rappels

À l'ouverture de l'app (et toutes les minutes tant qu'elle est ouverte), le moteur recalcule chaque client :

| Situation | Action |
|---|---|
| 5 jours avant l'échéance | Alarme + « Rappel : paiement dans 5 jours » + message tamoul J−5 |
| Jour de l'échéance | Alarme + « Le paiement est dû aujourd'hui » |
| En retard | Alarme + popup + liste des retards, **chaque jour** jusqu'à « ✅ Paiement reçu » |
| « Paiement reçu » cliqué | Rappels stoppés, statut « payé », le cycle repart automatiquement le mois suivant |

« Fermer pour aujourd'hui » fait taire un rappel jusqu'au lendemain (stocké dans IndexedDB).

Sur Android/Chrome avec l'app installée, la **synchronisation périodique en arrière-plan** envoie aussi une notification ~2×/jour même app fermée. Limite honnête des PWA : aucun navigateur ne garantit une alarme app totalement fermée (surtout iOS) — l'alarme complète se déclenche dès l'ouverture de l'app.

## 🗂 Structure

```
public/            manifest, service worker (sw.js), icônes
src/
  App.tsx          état global, moteur de rappels, navigation
  alarm.ts         son d'alarme (Web Audio), vibration, notifications
  db.ts            couche IndexedDB (clients, réglages, rappels ignorés)
  i18n.ts          traductions tamoul (défaut) + anglais
  types.ts
  utils/
    dates.ts       moteur de dates mensuelles automatiques
    messages.ts    modèles tamouls, variantes de ton, liens WhatsApp/Viber
  components/      Dashboard, Clients, ClientForm, CalendarView,
                   Reports, Templates, SettingsPanel, AlarmOverlay
netlify.toml       configuration de déploiement
```

---

## English summary

Modern offline-first PWA to manage monthly client payments. Automatic monthly due-date engine (due day 1–31, clamped per month, never edited manually), alarm-style reminders (loud sound, vibration, browser notification, full-screen popup) at 5 days before, on the due date, and daily while overdue until "Payment received". Editable Tamil message templates with auto-updating variables and friendly/professional/strict suggestions, one-click WhatsApp (pre-filled) and Viber (message copied) sending, search, filters, calendar, monthly reports, IndexedDB storage with JSON export/import, Tamil-first UI with English, dark/light Material Design 3. Deploy: push to Git and import on Netlify (`netlify.toml` included), or `netlify deploy --prod --dir=dist` after `npm run build`.
